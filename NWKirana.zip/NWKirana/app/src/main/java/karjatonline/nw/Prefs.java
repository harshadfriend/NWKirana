package karjatonline.nw;

public class Prefs {
    public static String StoreKey="Store";
    public static String  PinKey="0000";
}
